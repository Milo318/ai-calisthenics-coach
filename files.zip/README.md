# 🤖 AI Calisthenics Coach

Dein intelligenter Personal Trainer für Calisthenics - powered by AI!

## Features

- 💬 AI-powered Chat Coach (Hugging Face Mistral 7B)
- 💪 12 Calisthenics Übungen (Beginner bis Advanced)
- 📊 Progress Tracking & Stats
- ⏱️ Workout Timer
- 🎯 Personalisierte Workout Pläne

## 100% Kostenlos

Die App nutzt Hugging Face's kostenlose Inference API. Du kannst sie entweder:
- Ohne Token nutzen (~30 Requests/Stunde)
- Mit kostenlosem Token nutzen (unbegrenzt)

Token holen: https://huggingface.co/settings/tokens

## Tech Stack

- Pure HTML/CSS/JavaScript
- Hugging Face Inference API
- Mistral 7B Instruct Model
- Vercel Hosting

Built with ❤️ by Claude
