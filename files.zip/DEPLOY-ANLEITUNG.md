# 🚀 Deployment auf Vercel - 3 Minuten Setup

## Option 1: GitHub + Vercel (Empfohlen)

### Schritt 1: GitHub Repo erstellen
```bash
cd /pfad/zu/diesem/ordner
git init
git add .
git commit -m "Initial commit: AI Calisthenics Coach"
```

Dann auf github.com:
1. Neues Repo erstellen (z.B. "ai-calisthenics-coach")
2. Commands von GitHub kopieren und ausführen

### Schritt 2: Mit Vercel verbinden
1. Geh auf [vercel.com](https://vercel.com)
2. Sign in mit GitHub
3. Click "Add New..." → "Project"
4. Wähl dein GitHub Repo
5. Click "Deploy"

**Fertig!** Nach 30 Sekunden ist deine App live 🎉

---

## Option 2: Vercel CLI (Schneller)

```bash
# Vercel CLI installieren
npm install -g vercel

# Im Projekt-Ordner
vercel

# Folge den Prompts:
# - Set up and deploy? → Yes
# - Which scope? → Dein Account
# - Link to existing project? → No
# - Project name? → ai-calisthenics-coach
# - Directory? → ./
# - Override settings? → No

# Nach dem Deploy bekommst du eine URL!
```

---

## Option 3: Drag & Drop (Für Einsteiger)

1. Zippe diesen Ordner (alle Dateien)
2. Geh auf [vercel.com/new](https://vercel.com/new)
3. Drag & Drop die Zip-Datei
4. Click "Deploy"

**Done!**

---

## Nach dem Deploy

Deine App läuft auf einer URL wie:
`https://ai-calisthenics-coach.vercel.app`

### Custom Domain (Optional)
Vercel Settings → Domains → Add deiner-name.com

### Kosten
- **Vercel Hosting:** 100% Kostenlos
- **AI (Hugging Face):** 100% Kostenlos
- **Total:** €0/Monat 🎉

---

## Troubleshooting

**Problem:** "Build failed"
→ Check ob index.html im Root liegt

**Problem:** "Site not loading"
→ Warte 1-2 Minuten nach Deploy

**Problem:** AI funktioniert nicht
→ Hol dir Token auf huggingface.co/settings/tokens

---

Need help? Die App läuft als static site, super einfach!
